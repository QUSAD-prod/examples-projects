package com.ArtemOslopov.yana_guide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
