package com.ArtemOslopov.tiksiAvia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
