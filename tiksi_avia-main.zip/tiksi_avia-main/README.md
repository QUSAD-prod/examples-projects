# tiksi_avia
 
