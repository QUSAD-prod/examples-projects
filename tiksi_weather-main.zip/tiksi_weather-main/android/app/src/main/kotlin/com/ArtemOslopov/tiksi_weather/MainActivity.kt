package com.ArtemOslopov.tiksi_weather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
